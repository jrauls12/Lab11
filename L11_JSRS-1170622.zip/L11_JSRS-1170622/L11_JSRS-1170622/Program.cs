﻿using System;

class Program
{
    public static double conversionEuro3(double libra)
    {
        double eu3 = libra * 1.22;
        return eu3;
    }
    public static double conversionEuro(double dolares)
    {
        double eu1 = dolares * 0.75;
        return eu1;
    }
    public static double conversionEuro2(double yenes)
    {
        double eu2 = yenes * 0.009;
        return eu2;
    }
    public static double conversionEu3(double libra)
    {
        double eu3 = libra * 1.22;
        return eu3;
    }
    static void Main()
    {


        double a, b;
        Console.WriteLine("Ingrese dolares ");
        a = Double.Parse(Console.ReadLine());
        b = conversionEuro(a);
        Console.WriteLine("En euros son " + b);

        double e, f;
        Console.WriteLine("Ingrese libras ");
        e = Double.Parse(Console.ReadLine());
        f = conversionEu3(e);
        Console.WriteLine("En euros son" + f);

        double c, d;
        Console.WriteLine("Ingrese yenes ");
        c = Double.Parse(Console.ReadLine());
        d = conversionEuro2(c);
        Console.WriteLine("En euros son" + d);





    }

}
